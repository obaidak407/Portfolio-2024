---
date: 2012-08-25
published: true
order_number: 8
title: "Beehive"
description: "Art deco typeface"
categories: on sale, art deco
thumbnail: "/fonts/beehive/flist-beehive.svg"
banner: "/fonts/beehive/overview.png"
licensetype: Commercial

features:
  - 3 available styles

available_licenses:
  - Web
  - Desktop

supported_languages:

font_weights:
  - "Regular"
  - "Caps"
  - "Condensed"

vendors:
  - title: "Fontspring"
    licence: Webfont & Desktop
    url: "//www.fontspring.com/fonts/matt-grey-design/beehive"

  - title: "Myfonts"
    licence: Webfont & Desktop
    url: "//www.myfonts.com/fonts/matt-grey/beehive/"

initial_release: 2012
designed_from: 2012

releases:
  - version: v1.0
    releasedate: Oct 2012
    details: >
      - Released on Myfonts and Fontspring
---

